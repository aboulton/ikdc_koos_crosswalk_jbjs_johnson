#--- Top Matter ---------------------------------------------------------------#

library(shinyjs)

# Linking functions
#lf <- readRDS("./data/equipercentile_equating.rds")
lf_koos5_to_ikdc <- readRDS("./data/equipercentile_equating_koos5_to_ikdc.rds")
lf_koos4_to_ikdc <- readRDS("./data/equipercentile_equating_koos4_to_ikdc.rds")
lf_ikdc_to_koos5 <- readRDS("./data/equipercentile_equating_ikdc_to_koos5.rds")
lf_ikdc_to_koos4 <- readRDS("./data/equipercentile_equating_ikdc_to_koos4.rds")

#--- User Interface (UI) ------------------------------------------------------#

ui <- fluidPage(theme = "spacelab.css",
  tags$head(
    tags$link(rel = "stylesheet", type = "text/css", href = "css_hacks.css")
  ),
  titlePanel(HTML(paste0("A Crosswalk for Knee Outcomes after ACLR from the KOOS to the IKDC"))),
  sidebarLayout(
    # Side Panel
    sidebarPanel(
      fileInput("file", "Choose Dataset to Upload (.csv only)",
                multiple = FALSE,
                accept = c("text/csv",
                           "text/comma-separated-values,text/plain",
                           ".csv")),
      selectInput("crosswalk", "Select Crosswalk", selectize = FALSE,
                  choices = list("KOOS5 to IKDC-SKF" = "lf_koos5_to_ikdc",
                                 "KOOS4 to IKDC-SKF" = "lf_koos4_to_ikdc",
                                 "IKDC-SKF to KOOS5" = "lf_ikdc_to_koos5",
                                 "IKDC-SKF to KOOS4" = "lf_ikdc_to_koos4")),
      uiOutput("link_var"),
      textInput("new_name", "New Crosswalk Variable Name", value = ""),
      actionButton("link", "Compute Crosswalk Scores", width = "100%"),
      downloadButton("export", "Export Data"),
      actionButton("reset", "Start Over", width = "100%")
    ),
    # Main Panel
    mainPanel(
      withTags(
        tabsetPanel(id = "tabset_panel",
          tabPanel(title = "Background", value = "background",
            p(style = "padding-top:20px;",
              HTML(paste0("This application allows users to crosswalk composite
                          scores from the Knee Injury Osteoarthritis Outcomes
                          Survey (KOOS<sub>5</sub> or KOOS<sub>4</sub> scores) to
                          the International Knee Documentation Committee-Subjective
                          Knee Form (IKDC-SKF), and vice versa, as described in:"))),
            p(HTML(paste0("Johnson JL, Boulton AJ, Spindler KP, Huston LJ, Spalding T,
                          Asplin L, Risberg MA, Snyder-Mackler L. Creating a
                          crosswalk for knee outcomes after ACLR from the KOOS
                          to the IKDC. ", em("J Bone Joint Surg.")))),
            p("In this study, scores were linked using equipercentile equating, an
            established procedure for creating crosswalks between measures
            in the educational and
            health sciences. Such linkages are useful, for example, in longitudinal
            studies where developmental transitions occur (e.g., transition to adulthood)
            or when comparing two samples that completed different measures of the same (or similar)
              constructs."),
            p("Instructions for this application can be found under the
              'Instructions' tab."), 
            p("Users are advised that error is inevitably
            introduced when linking methods are used, a consequence of having to
            predict scores on a measure instead of directly administering the
            intended measure; therefore, crosswalks are best applied ad hoc and
            when a research design offers no alternative. In addition, linked
            scores produced using this calculator should not be used for
            individual-level decision-making; the crosswalks provided here are
            intended for use in group-level analysis only.")),
          tabPanel(title = "Instructions", value = "instructions",
            p(style = "padding-top:20px;", "To use the application, follow
              the steps below."),
            p(b("Step 1: Upload dataset."), " Click on the 'Browse' button in
              the left-hand column and upload a dataset (in .csv format)
              containing the variables to be linked. Once uploaded, the dataset will appear in the
              'Dataset' tab"),
            p(b("Step 2: Compute crosswalk scores."), HTML(" First, select which crosswalk
              to use in the 'Select Crosswalk' dropdown menu. There are four choices,
              corresponding to the four crosswalks described in the accompanying article.
              Next, select a variable in the dataset (via the 'Select Variable in Dataset to
              Link' drop down menu) containing the composite score from which crosswalked scores
              are to be computed. Next, type in the name of the
              variable to be created in the 'New Crosswalk Variable Name' dialog
              box; if a name is not provided, a default label will be
              assigned. Finally, press the 'Compute Crosswalk Scores' button; a new
              variable with the linked scores will appear in the dataset displayed.")),
            p("To start over with the original dataset, thereby removing any
              newly created variables, press the 'Start Over' button"),
            p(b("Step 3: Export dataset."), " Once scores have been crosswalked,
              press the 'Export Dataset' button to download a
              copy of the dataset displayed in the 'Dataset' tab that contains
              the new linkage variables. This dataset will appear in the user's
              system download directory."),
            br(),
            p("Questions or feedback? Please contact Aaron Boulton at
              aboulton at udel.edu")
          ),
          tabPanel(title = "Dataset", value = "dataset",
            uiOutput("dataset_tab")
        ))
      )
    )
  )
)

#--- Define server logic ------------------------------------------------------#

server <- function(input, output, session) {
  
  # Create reactiveValues object 'values'
  values <- reactiveValues(dataset = NULL)
  
  # Store data 
  observeEvent(input$file, {
    values$dataset <- read.csv(input$file$datapath)
    updateTabsetPanel(session, "tabset_panel", selected = "dataset")
  })
  
  # Render data table for display
  output$dataset <- DT::renderDataTable({
    req(input$file)
    values$dataset
  },
  options = list(scrollX = TRUE))
  
  output$dataset_tab <- renderUI({
    if(is.null(input$file)) {
      p(style = "padding-top:20px;", "Dataset not loaded")
    } else {
      wellPanel(
        DT::dataTableOutput("dataset")   
      )
    }
  })
    
  # Create linkage
  observeEvent(input$link, {
    if (input$new_name != "") {
      new_name <- input$new_name
    } else {
      new_name <- "koos_to_ikdc_crosswalked_scores"
    }
    crosswalk <- get(input$crosswalk)
    linked_var <- equate(values$dataset[, input$var],
                         y = crosswalk)
    out <- cbind.data.frame(new_name = linked_var, values$dataset)
    names(out)[names(out) == "new_name"] <- new_name
    values$dataset <- out
  })
  
  # Display variable names
  output$link_var <- renderUI({
    if (is.null(input$file)) {
      selectInput('var', 'Select Variable in Dataset to Crosswalk',
                  choices = "", selectize = FALSE)
    } else {
      selectInput('var', 'Select Variable in Dataset to  Crosswalk',
                  c(colnames(values$dataset)), selectize = FALSE)
      
    }
  })
  
  # Export Dataset csv of selected dataset ----
  output$export <- downloadHandler(
    filename = function() {
      paste("dataset_with_crosswalked_ikdc_scores.csv", sep = "")
    },
    content = function(file) {
      write.csv(values$dataset, file, row.names = FALSE)
    }
  )
  
  # Start over
  observeEvent(input$reset, {
    values$dataset <- read.csv(input$file$datapath)
    updateTabsetPanel(session, "tabset_panel", selected = "dataset")
  })
}

#--- Run the app --------------------------------------------------------------#
shinyApp(ui = ui, server = server)