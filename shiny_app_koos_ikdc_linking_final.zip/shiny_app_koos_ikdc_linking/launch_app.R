# Run the following code to launch application in web browser
#setwd("INSERT FILEPATH HERE")
for (i in c("shiny", "shinyjs", "equate")) {
  if(i %in% rownames(installed.packages()) == FALSE) {
    install.packages(i)
  }
}
library(shiny)
library(equate)
library(shinyjs)
runApp(launch.browser = TRUE, display.mode = "normal")